import os

class Config:
    SECRET_KEY = 'e348c4e4d7bcb9fd8a07d3d9b4ef6b9f'
    JWT_SECRET_KEY = 'HGFHGEAD1212432432'
    SQLALCHEMY_DATABASE_URI = 'mysql+mysqlconnector://username:password@localhost/db_name'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    UPLOAD_FOLDER = 'uploads/'

